package np.game.himalaya

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.random.Random

/** Everything the player has: where they are, strength, bag, score. Saved on the phone. */
class GameState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("adventure", Context.MODE_PRIVATE)

    var sceneId by mutableStateOf(Story.START)
    var hp by mutableIntStateOf(100)
    var items by mutableStateOf<Set<String>>(emptySet())
    var endings by mutableStateOf<Set<String>>(emptySet())
    var lastNote by mutableStateOf("")
    var started by mutableStateOf(false)

    var score by mutableIntStateOf(0)
    var finalScore by mutableIntStateOf(0)
    var bestScore by mutableIntStateOf(0)
    var newRecord by mutableStateOf(false)
    var runs by mutableIntStateOf(0)
    var defeated by mutableIntStateOf(0)

    var perk by mutableStateOf("none")
    var chosenPerk by mutableStateOf("none")
    var charmUsed by mutableStateOf(false)

    var enemyHp by mutableIntStateOf(0)
    var battleLog by mutableStateOf("")
    private var defending = false
    private var pendingNote = ""

    init {
        load()
    }

    val canContinue: Boolean
        get() = started && Story.scenes[sceneId]?.ending == null

    fun unlockedPerkIds(): Set<String> =
        Story.perks.filter { it.unlockedBy == null || it.unlockedBy in endings }.map { it.id }.toSet()

    fun newGame(perkId: String) {
        val allowed = unlockedPerkIds()
        perk = if (perkId in allowed) perkId else "none"
        chosenPerk = perk
        hp = 100
        score = 0
        finalScore = 0
        newRecord = false
        charmUsed = false
        defending = false
        lastNote = ""
        items = when (perk) {
            "pack" -> setOf("रोटी", "रस्सी")
            "golden" -> setOf("गुप्त राह")
            else -> emptySet()
        }
        started = true
        runs += 1
        enter(Story.START)
        save()
    }

    /** Changes strength. Returns true if the player is out of strength. */
    private fun changeHp(delta: Int): Boolean {
        var d = delta
        if (d < 0 && perk == "blanket") d = minOf(0, d + 5)
        var h = hp + d
        if (h <= 0 && perk == "charm" && !charmUsed) {
            charmUsed = true
            h = 30
            pendingNote = "🧿 ताबीज़ ने बचा लिया!"
        }
        hp = h.coerceIn(0, 100)
        return hp <= 0
    }

    private fun enter(id: String) {
        sceneId = id
        val sc = Story.scenes[id] ?: return
        val e = sc.enemy
        if (e != null) {
            enemyHp = e.hp
            battleLog = e.intro
            defending = false
        }
        val end = sc.ending
        if (end != null) finishRun(id, end)
    }

    private fun finishRun(id: String, end: Ending) {
        endings = endings + id
        val bonus = when (end) {
            Ending.WIN -> 100
            Ending.SECRET -> 150
            Ending.NEUTRAL -> 20
            Ending.LOSE -> 0
        }
        finalScore = score + hp + items.size * 3 + bonus
        if (finalScore > bestScore) {
            bestScore = finalScore
            newRecord = true
        } else {
            newRecord = false
        }
    }

    fun choose(c: Choice) {
        val need = c.needs
        if (need != null && need !in items) return
        val notes = ArrayList<String>()
        var target = c.next
        val ch = c.chance
        val fail = c.failNext
        if (ch != null && fail != null) {
            if (Random.nextInt(100) >= ch) {
                target = fail
                notes.add("🎲 भाग्य ने साथ नहीं दिया")
            } else {
                notes.add("🎲 भाग्य ने साथ दिया")
            }
        }
        if (target.startsWith("random:")) {
            target = target.removePrefix("random:").split("|").random()
        }
        for (g in c.give) notes.add(g + " मिला")
        for (t in c.take) notes.add(t + " खर्च हुआ")
        items = (items + c.give) - c.take.toSet()
        score += c.score
        if (c.score > 0) notes.add("+" + c.score + " अंक")

        pendingNote = ""
        val before = hp
        val dead = if (c.hp != 0) changeHp(c.hp) else false
        val diff = hp - before
        if (diff != 0) notes.add("ताक़त " + (if (diff > 0) "+" else "") + diff)
        if (pendingNote.isNotEmpty()) notes.add(pendingNote)

        lastNote = notes.joinToString("  ·  ")
        enter(if (dead) "end_frozen" else target)
        save()
    }

    // ----- battles -----

    fun attack() {
        val e = Story.scenes[sceneId]?.enemy ?: return
        val dmg = Random.nextInt(12, 25) + (if (perk == "stick") 6 else 0)
        enemyHp = (enemyHp - dmg).coerceAtLeast(0)
        battleLog = "⚔️ तुमने वार किया — " + e.name + " की ताक़त −" + dmg
        afterPlayerAction(e)
    }

    fun defend() {
        val e = Story.scenes[sceneId]?.enemy ?: return
        defending = true
        val heal = if (perk == "shield") 12 else 5
        changeHp(heal)
        battleLog = "🛡️ तुमने बचाव की मुद्रा ली और साँस सँभाली — ताक़त +" + heal
        afterPlayerAction(e)
    }

    fun useWeakness() {
        val e = Story.scenes[sceneId]?.enemy ?: return
        val w = e.weakItem ?: return
        if (w !in items) return
        if (e.weakConsumes) items = items - w
        enemyHp = (enemyHp - e.weakDmg).coerceAtLeast(0)
        battleLog = "✨ " + e.weakText
        afterPlayerAction(e)
    }

    fun flee() {
        val sc = Story.scenes[sceneId] ?: return
        pendingNote = ""
        val before = hp
        val dead = changeHp(-10)
        lastNote = "🏃 तुम पीछे हट गए  ·  ताक़त " + (hp - before)
        enter(if (dead) "end_beaten" else sc.fleeNext)
        save()
    }

    private fun afterPlayerAction(e: Enemy) {
        val sc = Story.scenes[sceneId] ?: return
        if (enemyHp <= 0) {
            score += 15
            defeated += 1
            lastNote = "🏆 " + e.name + " हारा!  ·  +15 अंक"
            enter(sc.winNext)
            save()
            return
        }
        var dmg = Random.nextInt(e.minDmg, e.maxDmg + 1)
        if (defending) dmg /= 2
        defending = false
        pendingNote = ""
        val before = hp
        val dead = changeHp(-dmg)
        val lost = maxOf(before - hp, 0)
        battleLog = battleLog + "\n💢 " + e.name + " ने वार किया — ताक़त −" + lost
        if (pendingNote.isNotEmpty()) battleLog = battleLog + "\n" + pendingNote
        if (dead) {
            lastNote = ""
            enter("end_beaten")
        }
        save()
    }

    // ----- saving -----

    private fun load() {
        val s = prefs.getString("scene", Story.START) ?: Story.START
        sceneId = if (Story.scenes[s] != null) s else Story.START
        hp = prefs.getInt("hp", 100)
        items = (prefs.getString("items", "") ?: "").split("|").filter { it.isNotEmpty() }.toSet()
        endings = (prefs.getString("endings", "") ?: "").split("|").filter { it.isNotEmpty() }.toSet()
        started = prefs.getBoolean("started", false)
        score = prefs.getInt("score", 0)
        finalScore = prefs.getInt("final", 0)
        bestScore = prefs.getInt("best", 0)
        runs = prefs.getInt("runs", 0)
        defeated = prefs.getInt("defeated", 0)
        perk = prefs.getString("perk", "none") ?: "none"
        chosenPerk = prefs.getString("chosen", "none") ?: "none"
        charmUsed = prefs.getBoolean("charm", false)
        enemyHp = prefs.getInt("enemyhp", 0)
        battleLog = prefs.getString("log", "") ?: ""
        val e = Story.scenes[sceneId]?.enemy
        if (e != null && enemyHp <= 0) {
            enemyHp = e.hp
            battleLog = e.intro
        }
    }

    private fun save() {
        prefs.edit()
            .putString("scene", sceneId)
            .putInt("hp", hp)
            .putString("items", items.joinToString("|"))
            .putString("endings", endings.joinToString("|"))
            .putBoolean("started", started)
            .putInt("score", score)
            .putInt("final", finalScore)
            .putInt("best", bestScore)
            .putInt("runs", runs)
            .putInt("defeated", defeated)
            .putString("perk", perk)
            .putString("chosen", chosenPerk)
            .putBoolean("charm", charmUsed)
            .putInt("enemyhp", enemyHp)
            .putString("log", battleLog)
            .apply()
    }
}
